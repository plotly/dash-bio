# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class ManPlot(Component):
    """A ManPlot component.


Keyword arguments:
- id (string; optional): The ID of this component, used to identify dash components
in callbacks. The ID needs to be unique across all of the
components in an app.
- dataframe (optional): A pandas dataframe which must contain at
       least the
           following  three columns:
               - the chromosome number
               - genomic base-pair position
               - a numeric quantity to plot such as a p-value or zscore. dataframe has the following type: dict containing keys 'effectSize', 'chromosomeNum', 'pVal', 'basePair', 'snp', 'gene', 'annotation'.
Those keys have the following types: 
  - effectSize (list; optional)
  - chromosomeNum (list; optional)
  - pVal (list; optional)
  - basePair (list; optional)
  - snp (list; optional)
  - gene (list; optional)
  - annotation (list; optional)
- effectSizeLine (list; optional)
- genomeWideLine (optional): . genomeWideLine has the following type: dict containing keys 'value', 'color', 'width'.
Those keys have the following types: 
  - value (number; optional)
  - color (string; optional)
  - width (number; optional)
- logp (optional): If true the -log10 of the p-value is plotted.
It isn't very useful to plot raw p-values, however plotting the raw
value could be useful for other genome-wide plots, for example,
peak heights, bayes factors, test statistics, other "scores" etc.
- title (string; optional): Title of the graph.
- xlabel (string; optional)
- ylabel (string; optional)

Available events: 'click', 'hover', 'unhover', 'selected'"""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, dataframe=Component.UNDEFINED, effectSizeLine=Component.UNDEFINED, genomeWideLine=Component.UNDEFINED, logp=Component.UNDEFINED, title=Component.UNDEFINED, xlabel=Component.UNDEFINED, ylabel=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'dataframe', 'effectSizeLine', 'genomeWideLine', 'logp', 'title', 'xlabel', 'ylabel']
        self._type = 'ManPlot'
        self._namespace = 'dash_bio'
        self._valid_wildcard_attributes =            []
        self.available_events = ['click', 'hover', 'unhover', 'selected']
        self.available_properties = ['id', 'dataframe', 'effectSizeLine', 'genomeWideLine', 'logp', 'title', 'xlabel', 'ylabel']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(ManPlot, self).__init__(**args)

    def __repr__(self):
        if(any(getattr(self, c, None) is not None
               for c in self._prop_names
               if c is not self._prop_names[0])
           or any(getattr(self, c, None) is not None
                  for c in self.__dict__.keys()
                  if any(c.startswith(wc_attr)
                  for wc_attr in self._valid_wildcard_attributes))):
            props_string = ', '.join([c+'='+repr(getattr(self, c, None))
                                      for c in self._prop_names
                                      if getattr(self, c, None) is not None])
            wilds_string = ', '.join([c+'='+repr(getattr(self, c, None))
                                      for c in self.__dict__.keys()
                                      if any([c.startswith(wc_attr)
                                      for wc_attr in
                                      self._valid_wildcard_attributes])])
            return ('ManPlot(' + props_string +
                   (', ' + wilds_string if wilds_string != '' else '') + ')')
        else:
            return (
                'ManPlot(' +
                repr(getattr(self, self._prop_names[0], None)) + ')')
