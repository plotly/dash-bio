def EmptyComponent():
    return ''
