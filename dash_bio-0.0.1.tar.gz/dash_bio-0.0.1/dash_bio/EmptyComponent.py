def EmptyComponent():
    return ''
