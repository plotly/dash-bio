from Bio import SeqIO


# information on database header formats, taken from
# https://en.wikipedia.org/wiki/FASTA_format
_databases = {
    'gb': ['accession', 'locus'],
    'emb': ['accession', 'locus'],
    'dbj': ['accession', 'locus'],
    'pir': ['entry'],
    'prf': ['name'],
    'sp': ['accession', '[entry name] [protein name] [OS=organism name] [OX=organism identifier] [GN=gene name] [PE=protein existence] [SV=sequence version]'],
    'tr': ['accession', '[entry name] [protein name] [OS=organism name] [OX=organism identifier] [GN=gene name] [PE=protein existence] [SV=sequence version]'],
    'pdb': ['entry', 'chain'],
    'pat': ['country', 'number'],
    'bbs': ['number'],
    'gnl': ['database', 'identifier'],
    'ref': ['accession', 'locus'],
    'lcl': ['identifier'],
    'nxp': ['identifier', 'gene name', 'protein name', 'isoform name']
}


def readFasta(
        filePath='',
        dataString='',
        cleanData=True
):
    proteins = []
    
    # ensure we are only given one file specification
    if(len(filePath) > 0 and len(dataString) > 0):
        raise Exception(
            "Please specify either a file path or a \
            string of data."
        )

    # will be used with SeqIO
    path = ''
    # SeqIO won't read bare sequences
    bareSeq = False
    rawDataString = ''
    
    # open file if given a path
    if(len(filePath) > 0):
        with open(filePath, 'r') as f:
            lines = f.readlines()
            if('>' not in lines[0]):
                bareSeq = True
                rawDataString = ('').join([
                    line.strip('\n') for line in lines
                ])
    else:
        rawDataString = dataString
    try:
        # create a temporary file
        with open('tmp.fasta', 'w+') as f:
            f.writelines(rawDataString)
    except exception:
        return proteins

    records = list(SeqIO.parse(filePath, 'fasta'))
    
    for i in range(len(records)):
        print(records[i])
        print()

readFasta('/Users/mammam/Downloads/NX_P05787.fasta.txt')

    
