from Bio import SeqIO
import tempfile


# information on database header formats, taken from
# https://en.wikipedia.org/wiki/FASTA_format
_databases = {
    'gb': ['accession', 'locus'],
    'emb': ['accession', 'locus'],
    'dbj': ['accession', 'locus'],
    'pir': ['entry'],
    'prf': ['name'],
    'sp': ['accession', '[entry name] [protein name] [OS=organism name] [OX=organism identifier] [GN=gene name] [PE=protein existence] [SV=sequence version]'],
    'tr': ['accession', '[entry name] [protein name] [OS=organism name] [OX=organism identifier] [GN=gene name] [PE=protein existence] [SV=sequence version]'],
    'pdb': ['entry', 'chain'],
    'pat': ['country', 'number'],
    'bbs': ['number'],
    'gnl': ['database', 'identifier'],
    'ref': ['accession', 'locus'],
    'lcl': ['identifier'],
    'nxp': ['identifier', 'gene name', 'protein name', 'isoform name']
}


def readFasta(
        filePath='',
        dataString='',
        cleanData=True
):
    proteins = []
    
    # ensure we are only given one file specification
    if(len(filePath) > 0 and len(dataString) > 0):
        raise Exception(
            "Please specify either a file path or a \
            string of data."
        )

    rawData = []
    
    # open file if given a path
    if(len(filePath) > 0):
        with open(filePath, 'r') as f:
            lines = f.readlines()
            if('>' not in lines[0]):
                rawData = ['>\n']
            rawData += lines
    else:
        lines = dataString.split('\n')
        if('>' not in lines[0]):
            rawData = ['>\n']
        rawData += lines

    records = list(SeqIO.parse('tmp.fasta', 'fasta'))

    proteins = [
        {'description': decode_description(r.description),
         'sequence': str(r.seq)} for r in records
    ]

    
def decode_description(description):
    if(len(description) == 0):
        return {'-1': 'no description'}
                   
    decoded = {}
    
    desc = description.split('|')
    if desc[0] in _databases:
        dbInfo = _databases[desc[0]]
        # shift by one, since first section in header describes
        # the database
        for i in range(len(desc)-1):
            decoded[dbInfo[i]] = desc[i+1]
    else:
        for i in range(len(desc)-1):
            decoded['desc-'+str(i)] = desc[i+1]
            
    return decoded


        
readFasta('/Users/mammam/Downloads/NX_P05787.fasta.txt')
